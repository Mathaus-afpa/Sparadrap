package sparadrap.mvc.views;

public class MainView {
}

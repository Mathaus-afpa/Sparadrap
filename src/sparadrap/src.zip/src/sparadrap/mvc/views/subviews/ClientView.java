package sparadrap.mvc.views.subviews;
import sparadrap.components.interfaces.IView;

import java.util.*;
public class ClientView {
    private static Map<String, IView> listeDesChamps = new HashMap<>();
}
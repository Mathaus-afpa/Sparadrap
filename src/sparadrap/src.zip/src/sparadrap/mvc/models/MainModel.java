package sparadrap.mvc.models;

import java.awt.*;

public class MainModel {

    private static final String police = "Calibri";
    public static Font CHAMP_TEXTE_FONT = new Font(police, Font.BOLD, 20);
    public static String REGEX_PAR_DEFAUT = ".*";
    public final static Color COULEUR_PRINCIPALE = Color.WHITE;
}
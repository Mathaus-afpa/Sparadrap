package sparadrap.mvc.models.submodels;

public class Client {
}

package sparadrap.mvc.controllers;

public class MainController {
}

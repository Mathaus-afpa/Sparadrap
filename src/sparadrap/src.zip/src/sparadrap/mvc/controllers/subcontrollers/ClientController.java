package sparadrap.mvc.controllers.subcontrollers;

public class ClientController {
}

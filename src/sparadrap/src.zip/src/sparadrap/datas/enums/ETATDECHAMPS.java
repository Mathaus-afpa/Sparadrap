package sparadrap.datas.enums;

public enum ETATDECHAMPS {
    VALIDE,
    INVALIDE,
    IDENTIQUE,
    INCONNU
}
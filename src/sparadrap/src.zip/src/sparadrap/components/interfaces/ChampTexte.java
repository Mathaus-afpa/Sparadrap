package sparadrap.components.interfaces;
import sparadrap.datas.enums.ETATDECHAMPS;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.util.regex.Pattern;
import static sparadrap.mvc.models.MainModel.*;
/**
 *
 */
public class ChampTexte extends JTextField implements IView {
    //
    public static final String CT_EXCEPTION = "Un ChampTexte a reçu une chaine nulle.";
    //
    private boolean aEteSauvegarde = false;
    private ETATDECHAMPS etat = ETATDECHAMPS.INCONNU;
    private String texte;
    //
    private final Pattern pattern;
    //
    private boolean verifierEtat() { return (etat == ETATDECHAMPS.IDENTIQUE || etat == ETATDECHAMPS.VALIDE); }
    //
    public ChampTexte(String regex) {
        super();
        this.texte = this.getText(); // retourne ""
        String expressionReguliere = (regex == null) ? REGEX_PAR_DEFAUT : regex;
        this.pattern = Pattern.compile(expressionReguliere);
        decorer();
        ecouter();
        modifierEtat(); // set ETATDECHAMPS.IDENTIQUE
        rendreNonEditable();
    }
    //
    private void decorer() {
        this.setBorder(null);
        this.setFont(CHAMP_TEXTE_FONT);
    }
    private void ecouter() {
        this.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                modifierEtat();
            }
            @Override
            public void removeUpdate(DocumentEvent e) {
                modifierEtat();
            }
            @Override
            public void changedUpdate(DocumentEvent e) {
            //do nothing.
            }
        });
    }
    private void modifierEtat() {
        etat = ETATDECHAMPS.INCONNU;
        String modificationTexte = this.getText();
        if (modificationTexte != null) {
            if (modificationTexte.equals(texte)) {
                etat = ETATDECHAMPS.IDENTIQUE;
                this.aEteSauvegarde = true;
            } else {
                etat = verifierModification(modificationTexte);
                this.aEteSauvegarde = false;
            }
        }
        if (this.isEditable()) {
            try {
                afficherEtat();
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }
    //
    private ETATDECHAMPS verifierModification(String modification) {
        if (pattern.matcher(modification).matches()) {
            return ETATDECHAMPS.VALIDE;
        } else {
            return ETATDECHAMPS.INVALIDE;
        }
    }
    private void afficherEtat() throws Exception {
        switch (etat) {
            case VALIDE -> this.setBackground(Color.green);
            case INVALIDE -> this.setBackground(Color.red);
            case IDENTIQUE -> this.setBackground(Color.cyan);
            case INCONNU -> throw new Exception(CT_EXCEPTION); // ne devrait jamais se produire.
            default -> this.setBackground(COULEUR_PRINCIPALE);
        }
    }
    //
    public void rendreNonEditable() {
        if (verifierEtat()) {
            this.setEditable(false);
            this.setFocusable(false);
            this.setOpaque(false);
            this.setBackground(COULEUR_PRINCIPALE);
        }
    }
    public void rendreEditable() {
        this.setEditable(true);
        this.setFocusable(true);
        this.setOpaque(true);
        modifierEtat();
    }
    //
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame fenetrePrincipale = new JFrame();
            fenetrePrincipale.setPreferredSize(new Dimension(800, 600));
            fenetrePrincipale.pack();
            fenetrePrincipale.setVisible(true);
            JPanel panel = new JPanel(new BorderLayout());
            fenetrePrincipale.setContentPane(panel);
            panel.setBackground(Color.BLACK);
            ChampTexte champTexte = new ChampTexte("^[A-Z][a-zA-Z-'À-ÿ]+(?: [A-Z][a-zA-Z-'À-ÿ]+)*$");
            panel.add(champTexte, BorderLayout.NORTH);
            JButton button = new JButton("APPUIE");
            button.addActionListener(actionEvent -> {
                if (champTexte.isEditable()) {
                    if (!champTexte.aEteSauvegarde()) {
                        int response = JOptionPane.showConfirmDialog(null, "Voulez-vous sauvegarder ?", "Confirmation", JOptionPane.YES_NO_OPTION);
                            if (response == JOptionPane.YES_OPTION) {
                                champTexte.valider();
                            }
                    }
                    champTexte.rendreNonEditable();
                } else {
                    champTexte.rendreEditable();
                }
            });
            JButton valider = new JButton("valider");
            valider.addActionListener(actionEvent -> champTexte.valider());
            JButton annuler = new JButton("annuler");
            annuler.addActionListener(actionEvent -> champTexte.reinitialiser());
            JPanel panel2 = new JPanel();
            panel.add(panel2, BorderLayout.SOUTH);
            panel2.add(button);
            panel2.add(valider);
            panel2.add(annuler);
        });
    }
    //
    @Override
    public void valider() {
        if (this.isEditable()) {
            if (verifierEtat()) {
                this.texte = this.getText();
                this.aEteSauvegarde = true;
                this.rendreNonEditable();
            } else {
                JOptionPane.showMessageDialog(null, "Vérifier votre saisie", "Avertissement", JOptionPane.WARNING_MESSAGE);
            }
        }
        // ne fait rien si n'est pas en edition.
    }
    @Override
    public void reinitialiser() {
        if (this.isEditable()) {
            this.setText(this.texte);
        }
        // ne fait rien si n'est pas en edition.
    }
    //
    public boolean aEteSauvegarde() {
        return aEteSauvegarde;
    }
}
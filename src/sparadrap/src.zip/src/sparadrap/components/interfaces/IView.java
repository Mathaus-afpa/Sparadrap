package sparadrap.components.interfaces;

public interface IView {
    void valider();
    void reinitialiser();
}